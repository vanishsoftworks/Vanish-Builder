@echo off
setlocal
cd /d "%~dp0Builder"

set "APP=%~dp0Builder\38485.pyw"
if not exist "%APP%" (
    echo 38485.pyw was not found in:
    echo %~dp0Builder
    pause
    exit /b 1
)

where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "" pythonw "%APP%"
    exit /b 0
)

where py >nul 2>&1
if %errorlevel%==0 (
    start "" py -3.12w "%APP%"
    exit /b 0
)

echo Python was not found. Install Python 3 and try again.
pause
exit /b 1
